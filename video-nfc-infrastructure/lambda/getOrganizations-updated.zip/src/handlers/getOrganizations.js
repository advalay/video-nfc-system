const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const { parseAuthUser } = require('../lib/permissions');
const { handleError } = require('../lib/errorHandler');

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

const TABLE_NAME = process.env.DYNAMODB_TABLE_ORGANIZATION || '';

exports.handler = async (event) => {
  try {
    // 認証チェック
    const user = parseAuthUser(event);
    
    // システム管理者のみアクセス可能
    if (!user.groups?.includes('system-admin')) {
      return {
        statusCode: 403,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,OPTIONS',
        },
        body: JSON.stringify({
          success: false,
          error: {
            message: 'アクセス権限がありません',
            code: 'FORBIDDEN'
          }
        })
      };
    }

    // 組織データを取得（すべての組織を取得）
    const scanCommand = new ScanCommand({
      TableName: TABLE_NAME
    });

    const result = await docClient.send(scanCommand);
    
    if (!result.Items) {
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,OPTIONS',
        },
        body: JSON.stringify({
          success: true,
          data: {
            organizations: []
          }
        })
      };
    }

    // 販売店データを取得
    const shops = result.Items.filter(item => item.organizationType?.S === 'store');
    
    // 組織データを整形
    const organizations = result.Items
      .filter(item => item.organizationType?.S === 'agency') // パートナー企業のみ
      .map(item => {
        const organizationId = item.organizationId?.S || '';
        // この組織に属する販売店数を計算
        const shopCount = shops.filter(shop => shop.parentId?.S === organizationId).length;
        
        return {
          organizationId,
          organizationName: item.organizationName?.S || '',
          shopCount,
          totalVideos: parseInt(item.totalVideos?.N || '0'),
          totalSize: parseInt(item.totalStorage?.N || '0'),
          monthlyVideos: 0,
          weeklyVideos: 0,
          status: item.status?.S || 'active',
          createdAt: item.createdAt?.S || new Date().toISOString(),
          shops: []
        };
      });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
      },
      body: JSON.stringify({
        success: true,
        data: {
          organizations
        }
      })
    };

  } catch (error) {
    console.error('Error in getOrganizations:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
      },
      body: JSON.stringify({
        success: false,
        error: {
          message: error.message || 'Internal server error',
          code: 'INTERNAL_SERVER_ERROR'
        }
      })
    };
  }
};
