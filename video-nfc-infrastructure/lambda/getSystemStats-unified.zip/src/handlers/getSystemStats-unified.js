const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const { parseAuthUser } = require('../lib/permissions');

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

const TABLE_NAME = process.env.DYNAMODB_TABLE_ORGANIZATION || '';

exports.handler = async (event) => {
  try {
    const user = parseAuthUser(event);
    if (!user.groups?.includes('system-admin')) {
      return {
        statusCode: 403,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,OPTIONS',
        },
        body: JSON.stringify({
          success: false,
          error: {
            message: 'アクセス権限がありません',
            code: 'FORBIDDEN'
          }
        })
      };
    }

    // 組織データを取得（すべての組織を取得）
    const scanCommand = new ScanCommand({
      TableName: TABLE_NAME
    });

    const result = await docClient.send(scanCommand);

    if (!result.Items) {
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,OPTIONS',
        },
        body: JSON.stringify({
          success: true,
          data: {
            totalOrganizations: 0,
            totalShops: 0,
            totalVideos: 0,
            totalSize: 0,
            totalMonthlyVideos: 0,
            totalWeeklyVideos: 0,
            organizationStats: [],
            monthlyTrend: []
          }
        })
      };
    }

    // 販売店データを取得
    const shops = result.Items.filter(item => item.organizationType === 'store');
    
    // 組織データを整形（activeな組織のみ）
    const organizations = result.Items
      .filter(item => item.organizationType === 'agency' && item.status === 'active')
      .map(item => {
        const organizationId = item.organizationId || '';
        // この組織に属する販売店数を計算
        const shopCount = shops.filter(shop => shop.parentId === organizationId).length;
        
        return {
          organizationId,
          organizationName: item.organizationName || '',
          shopCount,
          totalVideos: parseInt(item.totalVideos || '0'),
          totalSize: parseInt(item.totalStorage || '0'),
          monthlyVideos: 0,
          weeklyVideos: 0,
          status: item.status || 'active',
          createdAt: item.createdAt || new Date().toISOString(),
          shops: []
        };
      });

    // 全体の統計を計算
    const totalOrganizations = organizations.length;
    const totalShops = organizations.reduce((sum, org) => sum + org.shopCount, 0);
    const totalVideos = organizations.reduce((sum, org) => sum + org.totalVideos, 0);
    const totalSize = organizations.reduce((sum, org) => sum + org.totalSize, 0);
    const totalMonthlyVideos = organizations.reduce((sum, org) => sum + org.monthlyVideos, 0);
    const totalWeeklyVideos = organizations.reduce((sum, org) => sum + org.weeklyVideos, 0);

    // 月別トレンド（過去6ヶ月）- 簡易版
    const monthlyTrend = [];
    for (let i = 5; i >= 0; i--) {
      const date = new Date();
      date.setMonth(date.getMonth() - i);
      monthlyTrend.push({
        month: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`,
        count: 0, // 実際の動画データがないため0
        size: 0
      });
    }

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
      },
      body: JSON.stringify({
        success: true,
        data: {
          totalOrganizations,
          totalShops,
          totalVideos,
          totalSize,
          totalMonthlyVideos,
          totalWeeklyVideos,
          organizationStats: organizations,
          monthlyTrend
        }
      })
    };

  } catch (error) {
    console.error('Error in getSystemStats:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
      },
      body: JSON.stringify({
        success: false,
        error: {
          message: error.message || 'Internal server error',
          code: 'INTERNAL_SERVER_ERROR'
        }
      })
    };
  }
};
