const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const { parseAuthUser } = require('../lib/permissions');
const { handleError } = require('../lib/errorHandler');

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

const TABLE_NAME = process.env.DYNAMODB_TABLE_ORGANIZATION || '';

exports.handler = async (event) => {
  try {
    // 認証チェック
    const user = parseAuthUser(event);
    
    // システム管理者のみアクセス可能
    if (!user.groups?.includes('system-admin')) {
      return {
        statusCode: 403,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,OPTIONS',
        },
        body: JSON.stringify({
          success: false,
          error: {
            message: 'アクセス権限がありません',
            code: 'FORBIDDEN'
          }
        })
      };
    }

    // 組織データを取得（すべての組織を取得）
    const scanCommand = new ScanCommand({
      TableName: TABLE_NAME
    });

    const result = await docClient.send(scanCommand);
    
    if (!result.Items) {
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,OPTIONS',
        },
        body: JSON.stringify({
          success: true,
          data: {
            organizations: []
          }
        })
      };
    }

    // 販売店データを取得
    const shops = result.Items.filter(item => item.organizationType === 'store');
    
    // デバッグログを追加
    console.log('Total items from DynamoDB:', result.Items?.length || 0);
    console.log('Items with organizationType agency:', result.Items?.filter(item => item.organizationType === 'agency').length || 0);
    
    // 組織データを整形
    const organizations = result.Items
      .filter(item => item.organizationType === 'agency') // パートナー企業のみ
      .map(item => {
        const organizationId = item.organizationId || '';
        // この組織に属する販売店数を計算
        const shopCount = shops.filter(shop => shop.parentId === organizationId).length;
        
        const org = {
          organizationId,
          organizationName: item.organizationName || '',
          shopCount,
          totalVideos: parseInt(item.totalVideos || '0'),
          totalSize: parseInt(item.totalStorage || '0'),
          monthlyVideos: 0,
          weeklyVideos: 0,
          status: item.status || 'active',
          createdAt: item.createdAt || new Date().toISOString(),
          shops: []
        };
        console.log('Processed organization:', org);
        return org;
      });
    
    console.log('Final organizations count:', organizations.length);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
      },
      body: JSON.stringify({
        success: true,
        data: {
          organizations
        }
      })
    };

  } catch (error) {
    console.error('Error in getOrganizations:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
      },
      body: JSON.stringify({
        success: false,
        error: {
          message: error.message || 'Internal server error',
          code: 'INTERNAL_SERVER_ERROR'
        }
      })
    };
  }
};
