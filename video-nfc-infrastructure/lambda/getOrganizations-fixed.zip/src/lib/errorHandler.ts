import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';

export interface ErrorLog {
  level: 'ERROR' | 'WARN' | 'INFO';
  timestamp: string;
  requestId: string;
  functionName: string;
  userId?: string;
  organizationId?: string;
  shopId?: string;
  path?: string;
  method?: string;
  error: {
    message: string;
    stack?: string;
    code?: string;
    type: string;
  };
  requestBody?: any;
  queryParams?: any;
  pathParams?: any;
}

/**
 * エラーを詳細にログ出力し、適切なHTTPレスポンスを返す
 */
export function handleError(
  error: unknown,
  event: APIGatewayProxyEvent,
  functionName: string
): APIGatewayProxyResult {
  const requestId = event.requestContext.requestId;
  const claims = event.requestContext?.authorizer?.claims;
  
  // エラーの型を判定
  const isError = error instanceof Error;
  const errorMessage = isError ? error.message : String(error);
  const errorStack = isError ? error.stack : undefined;
  const errorType = isError ? error.constructor.name : typeof error;

  // 詳細なエラーログを構造化して出力
  const errorLog: ErrorLog = {
    level: 'ERROR',
    timestamp: new Date().toISOString(),
    requestId,
    functionName,
    userId: claims?.sub as string,
    organizationId: claims?.['custom:organizationId'] as string,
    shopId: claims?.['custom:shopId'] as string,
    path: event.path,
    method: event.httpMethod,
    error: {
      message: errorMessage,
      stack: errorStack,
      type: errorType,
    },
    requestBody: event.body ? safeJsonParse(event.body) : undefined,
    queryParams: event.queryStringParameters,
    pathParams: event.pathParameters,
  };

  // CloudWatch Logsに構造化ログを出力（JSON形式）
  console.error(JSON.stringify(errorLog, null, 2));

  // エラーメッセージをスタックトレースと共に出力（検索しやすくする）
  console.error(`ERROR: ${errorMessage}`);
  if (errorStack) {
    console.error(`Stack trace:\n${errorStack}`);
  }

  // HTTPステータスコードを決定
  let statusCode = 500;
  let errorCode = 'INTERNAL_SERVER_ERROR';

  if (errorMessage.includes('認証') || errorMessage.includes('権限')) {
    statusCode = 403;
    errorCode = 'FORBIDDEN';
  } else if (errorMessage.includes('見つかりません') || errorMessage.includes('存在しません')) {
    statusCode = 404;
    errorCode = 'NOT_FOUND';
  } else if (errorMessage.includes('必須') || errorMessage.includes('不正') || errorMessage.includes('無効')) {
    statusCode = 400;
    errorCode = 'BAD_REQUEST';
  }

  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
    },
    body: JSON.stringify({
      success: false,
      error: {
        code: errorCode,
        message: errorMessage,
        requestId, // クライアントがサポートに問い合わせる際に使用
      },
    }),
  };
}

/**
 * 安全にJSONをパースする（パース失敗時は元の文字列を返す）
 */
function safeJsonParse(jsonString: string): any {
  try {
    return JSON.parse(jsonString);
  } catch {
    return jsonString;
  }
}

/**
 * 情報ログを出力（構造化）
 */
export function logInfo(message: string, data?: any, event?: APIGatewayProxyEvent): void {
  const claims = event?.requestContext?.authorizer?.claims;
  
  const log = {
    level: 'INFO',
    timestamp: new Date().toISOString(),
    requestId: event?.requestContext.requestId,
    userId: claims?.sub as string,
    organizationId: claims?.['custom:organizationId'] as string,
    message,
    data,
  };
  
  console.log(JSON.stringify(log));
}

/**
 * 警告ログを出力（構造化）
 */
export function logWarn(message: string, data?: any, event?: APIGatewayProxyEvent): void {
  const claims = event?.requestContext?.authorizer?.claims;
  
  const log = {
    level: 'WARN',
    timestamp: new Date().toISOString(),
    requestId: event?.requestContext.requestId,
    userId: claims?.sub as string,
    organizationId: claims?.['custom:organizationId'] as string,
    message,
    data,
  };
  
  console.warn(JSON.stringify(log));
}


