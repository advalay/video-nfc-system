export interface AuthUser {
    userId: string;
    email: string;
    groups: string[];
    role: string;
    organizationId?: string;
    shopId?: string;
}
export declare function parseAuthUser(event: any): AuthUser;
export declare function hasPermission(user: AuthUser, requiredRole: string): boolean;
export declare function canAccessOrganization(user: AuthUser, targetOrgId: string): boolean;
