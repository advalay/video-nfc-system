export interface AuthUser {
  userId: string;
  email: string;
  groups: string[];
  role: string;
  organizationId?: string;
  shopId?: string;
}

export function parseAuthUser(event: any): AuthUser {
  const claims = event.requestContext?.authorizer?.claims;
  
  if (!claims) {
    throw new Error('認証情報が見つかりません');
  }
  
  // Cognitoのカスタム属性から組織情報を取得
  const organizationId = claims['custom:organizationId'];
  const shopId = claims['custom:shopId'];
  const role = claims['custom:role'] || 'user';
  
  // グループ情報を取得
  const groups = claims['cognito:groups'] || [];
  
  return {
    userId: claims.sub,
    email: claims.email,
    groups,
    role,
    organizationId,
    shopId,
  };
}

export function hasPermission(user: AuthUser, requiredRole: string): boolean {
  const roleHierarchy = {
    'system-admin': 3,
    'agency-admin': 2,
    'store-admin': 1,
    'user': 0,
  };
  
  const userLevel = roleHierarchy[user.role as keyof typeof roleHierarchy] || 0;
  const requiredLevel = roleHierarchy[requiredRole as keyof typeof roleHierarchy] || 0;
  
  return userLevel >= requiredLevel;
}

export function canAccessOrganization(user: AuthUser, targetOrgId: string): boolean {
  // システム管理者は全組織にアクセス可能
  if (user.groups.includes('system-admin')) {
    return true;
  }
  
  // 代理店管理者は自組織と配下の販売店にアクセス可能
  if (user.role === 'agency-admin' && user.organizationId === targetOrgId) {
    return true;
  }
  
  // 販売店管理者は自店舗のみ
  if (user.role === 'store-admin' && user.shopId === targetOrgId) {
    return true;
  }
  
  return false;
}

