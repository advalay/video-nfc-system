import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export interface ErrorLog {
    level: 'ERROR' | 'WARN' | 'INFO';
    timestamp: string;
    requestId: string;
    functionName: string;
    userId?: string;
    organizationId?: string;
    shopId?: string;
    path?: string;
    method?: string;
    error: {
        message: string;
        stack?: string;
        code?: string;
        type: string;
    };
    requestBody?: any;
    queryParams?: any;
    pathParams?: any;
}
/**
 * エラーを詳細にログ出力し、適切なHTTPレスポンスを返す
 */
export declare function handleError(error: unknown, event: APIGatewayProxyEvent, functionName: string): APIGatewayProxyResult;
/**
 * 情報ログを出力（構造化）
 */
export declare function logInfo(message: string, data?: any, event?: APIGatewayProxyEvent): void;
/**
 * 警告ログを出力（構造化）
 */
export declare function logWarn(message: string, data?: any, event?: APIGatewayProxyEvent): void;
