const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const { verifyToken } = require('../lib/permissions');
const { handleError } = require('../lib/errorHandler');

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

const TABLE_NAME = process.env.DYNAMODB_TABLE_ORGANIZATION || '';

exports.handler = async (event) => {
  try {
    // 認証チェック
    const user = await verifyToken(event);
    
    // システム管理者のみアクセス可能
    if (!user.groups?.includes('system-admin')) {
      return {
        statusCode: 403,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,OPTIONS',
        },
        body: JSON.stringify({
          success: false,
          error: {
            message: 'アクセス権限がありません',
            code: 'FORBIDDEN'
          }
        })
      };
    }

    // 組織データを取得
    const scanCommand = new ScanCommand({
      TableName: TABLE_NAME,
      FilterExpression: 'attribute_not_exists(#status) OR #status <> :suspended',
      ExpressionAttributeNames: {
        '#status': 'status'
      },
      ExpressionAttributeValues: {
        ':suspended': 'suspended'
      }
    });

    const result = await docClient.send(scanCommand);
    
    if (!result.Items) {
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
          'Access-Control-Allow-Methods': 'GET,OPTIONS',
        },
        body: JSON.stringify({
          success: true,
          data: {
            organizations: []
          }
        })
      };
    }

    // 組織データを整形
    const organizations = result.Items
      .filter(item => item.type === 'organization')
      .map(item => ({
        organizationId: item.organizationId || item.id,
        organizationName: item.name || item.organizationName,
        shopCount: item.shopCount || 0,
        totalVideos: item.totalVideos || 0,
        totalSize: item.totalSize || 0,
        monthlyVideos: item.monthlyVideos || 0,
        weeklyVideos: item.weeklyVideos || 0,
        status: item.status || 'active',
        createdAt: item.createdAt || new Date().toISOString(),
        updatedAt: item.updatedAt,
        shops: item.shops || []
      }));

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
      },
      body: JSON.stringify({
        success: true,
        data: {
          organizations
        }
      })
    };

  } catch (error) {
    console.error('Error in getOrganizations:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
      },
      body: JSON.stringify({
        success: false,
        error: {
          message: error.message || 'Internal server error',
          code: 'INTERNAL_SERVER_ERROR'
        }
      })
    };
  }
};
