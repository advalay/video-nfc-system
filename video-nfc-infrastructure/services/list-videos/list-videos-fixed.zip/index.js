"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamoClient = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
const TABLE_NAME = process.env.DYNAMODB_TABLE_VIDEO;
// CORSヘッダーを定義
const CORS_HEADERS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
    'Access-Control-Allow-Credentials': 'true'
};
const handler = async (event) => {
    try {
        const queryParams = event.queryStringParameters || {};
        const limit = queryParams.limit ? parseInt(queryParams.limit, 10) : 50;
        const search = queryParams.search;
        let lastEvaluatedKey;
        if (queryParams.lastEvaluatedKey) {
            try {
                lastEvaluatedKey = JSON.parse(decodeURIComponent(queryParams.lastEvaluatedKey));
            }
            catch (e) {
                return {
                    statusCode: 400,
                    headers: CORS_HEADERS,
                    body: JSON.stringify({
                        success: false,
                        error: {
                            code: 'INVALID_PARAMETER',
                            message: 'Invalid lastEvaluatedKey format',
                        },
                    }),
                };
            }
        }
        // 開発環境では認証をスキップ
        let claims, userGroups, organizationId, shopId;
        if (process.env.ENVIRONMENT === 'dev' && event.headers?.['x-development-mode'] === 'true') {
            console.log('Development mode: Skipping authentication');
            claims = null;
            userGroups = ['system-admin'];
            organizationId = null;
            shopId = null;
        }
        else {
            // ユーザー情報を取得（Cognitoから）
            claims = event.requestContext?.authorizer?.claims;
            userGroups = claims?.['cognito:groups'] || [];
            organizationId = claims?.['custom:organizationId'];
            shopId = claims?.['custom:shopId'];
        }
        let result;
        if (userGroups.includes('system-admin')) {
            // system-admin: 全動画を閲覧可能
            const command = new lib_dynamodb_1.ScanCommand({
                TableName: TABLE_NAME,
                Limit: limit,
                ExclusiveStartKey: lastEvaluatedKey,
            });
            result = await docClient.send(command);
        }
        else if (userGroups.includes('organization-admin') && organizationId) {
            // organization-admin: 自分の代理店配下の全動画を閲覧可能（全販売店含む）
            const command = new lib_dynamodb_1.QueryCommand({
                TableName: TABLE_NAME,
                IndexName: 'organizationId-uploadDate-index',
                KeyConditionExpression: 'organizationId = :organizationId',
                ExpressionAttributeValues: {
                    ':organizationId': organizationId,
                },
                Limit: limit,
                ExclusiveStartKey: lastEvaluatedKey,
                ScanIndexForward: false, // 新しい順
            });
            result = await docClient.send(command);
        }
        else if (userGroups.includes('shop-user') && shopId) {
            // shop-user: 自分の販売店の動画のみ閲覧可能
            const command = new lib_dynamodb_1.QueryCommand({
                TableName: TABLE_NAME,
                IndexName: 'shopId-uploadDate-index',
                KeyConditionExpression: 'shopId = :shopId',
                ExpressionAttributeValues: {
                    ':shopId': shopId,
                },
                Limit: limit,
                ExclusiveStartKey: lastEvaluatedKey,
                ScanIndexForward: false, // 新しい順
            });
            result = await docClient.send(command);
        }
        else {
            return {
                statusCode: 403,
                headers: CORS_HEADERS,
                body: JSON.stringify({
                    success: false,
                    error: {
                        code: 'FORBIDDEN',
                        message: 'Access denied',
                    },
                }),
            };
        }
        // 検索フィルタリング（クライアント側）
        let items = result.Items || [];
        if (search) {
            const searchLower = search.toLowerCase();
            items = items.filter((item) => item.title?.toLowerCase().includes(searchLower) ||
                item.description?.toLowerCase().includes(searchLower) ||
                item.videoId?.toLowerCase().includes(searchLower));
        }
        return {
            statusCode: 200,
            headers: CORS_HEADERS,
            body: JSON.stringify({
                success: true,
                data: {
                    videos: items,
                    totalCount: items.length,
                    lastEvaluatedKey: result.LastEvaluatedKey
                        ? encodeURIComponent(JSON.stringify(result.LastEvaluatedKey))
                        : null,
                },
            }),
        };
    }
    catch (error) {
        console.error('Error listing videos:', error);
        return {
            statusCode: 500,
            headers: CORS_HEADERS,
            body: JSON.stringify({
                success: false,
                error: {
                    code: 'INTERNAL_SERVER_ERROR',
                    message: 'Failed to list videos',
                },
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSw4REFBMEQ7QUFDMUQsd0RBQTBGO0FBRTFGLE1BQU0sWUFBWSxHQUFHLElBQUksZ0NBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUM1QyxNQUFNLFNBQVMsR0FBRyxxQ0FBc0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7QUFFNUQsTUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBcUIsQ0FBQztBQUVyRCxjQUFjO0FBQ2QsTUFBTSxZQUFZLEdBQUc7SUFDbkIsY0FBYyxFQUFFLGtCQUFrQjtJQUNsQyw2QkFBNkIsRUFBRSxHQUFHO0lBQ2xDLDhCQUE4QixFQUFFLHNFQUFzRTtJQUN0Ryw4QkFBOEIsRUFBRSx5QkFBeUI7SUFDekQsa0NBQWtDLEVBQUUsTUFBTTtDQUMzQyxDQUFDO0FBUUssTUFBTSxPQUFPLEdBQTJCLEtBQUssRUFBRSxLQUFLLEVBQWtDLEVBQUU7SUFDN0YsSUFBSSxDQUFDO1FBQ0gsTUFBTSxXQUFXLEdBQTBCLEtBQUssQ0FBQyxxQkFBcUIsSUFBSSxFQUFFLENBQUM7UUFDN0UsTUFBTSxLQUFLLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUN2RSxNQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDO1FBRWxDLElBQUksZ0JBQWdCLENBQUM7UUFDckIsSUFBSSxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUNqQyxJQUFJLENBQUM7Z0JBQ0gsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO1lBQ2xGLENBQUM7WUFBQyxPQUFPLENBQUMsRUFBRSxDQUFDO2dCQUNYLE9BQU87b0JBQ0wsVUFBVSxFQUFFLEdBQUc7b0JBQ2YsT0FBTyxFQUFFLFlBQVk7b0JBQ3JCLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO3dCQUNuQixPQUFPLEVBQUUsS0FBSzt3QkFDZCxLQUFLLEVBQUU7NEJBQ0wsSUFBSSxFQUFFLG1CQUFtQjs0QkFDekIsT0FBTyxFQUFFLGlDQUFpQzt5QkFDM0M7cUJBQ0YsQ0FBQztpQkFDSCxDQUFDO1lBQ0osQ0FBQztRQUNILENBQUM7UUFFRCxnQkFBZ0I7UUFDaEIsSUFBSSxNQUFNLEVBQUUsVUFBb0IsRUFBRSxjQUFjLEVBQUUsTUFBTSxDQUFDO1FBRXpELElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEtBQUssS0FBSyxJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLE1BQU0sRUFBRSxDQUFDO1lBQzFGLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkNBQTJDLENBQUMsQ0FBQztZQUN6RCxNQUFNLEdBQUcsSUFBSSxDQUFDO1lBQ2QsVUFBVSxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDOUIsY0FBYyxHQUFHLElBQUksQ0FBQztZQUN0QixNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ2hCLENBQUM7YUFBTSxDQUFDO1lBQ04sdUJBQXVCO1lBQ3ZCLE1BQU0sR0FBRyxLQUFLLENBQUMsY0FBYyxFQUFFLFVBQVUsRUFBRSxNQUFNLENBQUM7WUFDbEQsVUFBVSxHQUFHLE1BQU0sRUFBRSxDQUFDLGdCQUFnQixDQUFDLElBQUksRUFBRSxDQUFDO1lBQzlDLGNBQWMsR0FBRyxNQUFNLEVBQUUsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1lBQ25ELE1BQU0sR0FBRyxNQUFNLEVBQUUsQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUNyQyxDQUFDO1FBRUQsSUFBSSxNQUFNLENBQUM7UUFFWCxJQUFJLFVBQVUsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQztZQUN4Qyx5QkFBeUI7WUFDekIsTUFBTSxPQUFPLEdBQUcsSUFBSSwwQkFBVyxDQUFDO2dCQUM5QixTQUFTLEVBQUUsVUFBVTtnQkFDckIsS0FBSyxFQUFFLEtBQUs7Z0JBQ1osaUJBQWlCLEVBQUUsZ0JBQWdCO2FBQ3BDLENBQUMsQ0FBQztZQUNILE1BQU0sR0FBRyxNQUFNLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDekMsQ0FBQzthQUFNLElBQUksVUFBVSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLGNBQWMsRUFBRSxDQUFDO1lBQ3ZFLGdEQUFnRDtZQUNoRCxNQUFNLE9BQU8sR0FBRyxJQUFJLDJCQUFZLENBQUM7Z0JBQy9CLFNBQVMsRUFBRSxVQUFVO2dCQUNyQixTQUFTLEVBQUUsaUNBQWlDO2dCQUM1QyxzQkFBc0IsRUFBRSxrQ0FBa0M7Z0JBQzFELHlCQUF5QixFQUFFO29CQUN6QixpQkFBaUIsRUFBRSxjQUFjO2lCQUNsQztnQkFDRCxLQUFLLEVBQUUsS0FBSztnQkFDWixpQkFBaUIsRUFBRSxnQkFBZ0I7Z0JBQ25DLGdCQUFnQixFQUFFLEtBQUssRUFBRSxPQUFPO2FBQ2pDLENBQUMsQ0FBQztZQUNILE1BQU0sR0FBRyxNQUFNLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDekMsQ0FBQzthQUFNLElBQUksVUFBVSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUN0RCw2QkFBNkI7WUFDN0IsTUFBTSxPQUFPLEdBQUcsSUFBSSwyQkFBWSxDQUFDO2dCQUMvQixTQUFTLEVBQUUsVUFBVTtnQkFDckIsU0FBUyxFQUFFLHlCQUF5QjtnQkFDcEMsc0JBQXNCLEVBQUUsa0JBQWtCO2dCQUMxQyx5QkFBeUIsRUFBRTtvQkFDekIsU0FBUyxFQUFFLE1BQU07aUJBQ2xCO2dCQUNELEtBQUssRUFBRSxLQUFLO2dCQUNaLGlCQUFpQixFQUFFLGdCQUFnQjtnQkFDbkMsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLE9BQU87YUFDakMsQ0FBQyxDQUFDO1lBQ0gsTUFBTSxHQUFHLE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN6QyxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU87Z0JBQ0wsVUFBVSxFQUFFLEdBQUc7Z0JBQ2YsT0FBTyxFQUFFLFlBQVk7Z0JBQ3JCLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUNuQixPQUFPLEVBQUUsS0FBSztvQkFDZCxLQUFLLEVBQUU7d0JBQ0wsSUFBSSxFQUFFLFdBQVc7d0JBQ2pCLE9BQU8sRUFBRSxlQUFlO3FCQUN6QjtpQkFDRixDQUFDO2FBQ0gsQ0FBQztRQUNKLENBQUM7UUFFRCxxQkFBcUI7UUFDckIsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUM7UUFDL0IsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUNYLE1BQU0sV0FBVyxHQUFHLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUN6QyxLQUFLLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQVMsRUFBRSxFQUFFLENBQ2pDLElBQUksQ0FBQyxLQUFLLEVBQUUsV0FBVyxFQUFFLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQztnQkFDL0MsSUFBSSxDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUUsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDO2dCQUNyRCxJQUFJLENBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FDbEQsQ0FBQztRQUNKLENBQUM7UUFFRCxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixPQUFPLEVBQUUsWUFBWTtZQUNyQixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDbkIsT0FBTyxFQUFFLElBQUk7Z0JBQ2IsSUFBSSxFQUFFO29CQUNKLE1BQU0sRUFBRSxLQUFLO29CQUNiLFVBQVUsRUFBRSxLQUFLLENBQUMsTUFBTTtvQkFDeEIsZ0JBQWdCLEVBQUUsTUFBTSxDQUFDLGdCQUFnQjt3QkFDdkMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUM7d0JBQzdELENBQUMsQ0FBQyxJQUFJO2lCQUNUO2FBQ0YsQ0FBQztTQUNILENBQUM7SUFDSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDOUMsT0FBTztZQUNMLFVBQVUsRUFBRSxHQUFHO1lBQ2YsT0FBTyxFQUFFLFlBQVk7WUFDckIsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ25CLE9BQU8sRUFBRSxLQUFLO2dCQUNkLEtBQUssRUFBRTtvQkFDTCxJQUFJLEVBQUUsdUJBQXVCO29CQUM3QixPQUFPLEVBQUUsdUJBQXVCO2lCQUNqQzthQUNGLENBQUM7U0FDSCxDQUFDO0lBQ0osQ0FBQztBQUNILENBQUMsQ0FBQztBQXJJVyxRQUFBLE9BQU8sV0FxSWxCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQVBJR2F0ZXdheVByb3h5SGFuZGxlciwgQVBJR2F0ZXdheVByb3h5UmVzdWx0IH0gZnJvbSAnYXdzLWxhbWJkYSc7XG5pbXBvcnQgeyBEeW5hbW9EQkNsaWVudCB9IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC1keW5hbW9kYic7XG5pbXBvcnQgeyBEeW5hbW9EQkRvY3VtZW50Q2xpZW50LCBRdWVyeUNvbW1hbmQsIFNjYW5Db21tYW5kIH0gZnJvbSAnQGF3cy1zZGsvbGliLWR5bmFtb2RiJztcblxuY29uc3QgZHluYW1vQ2xpZW50ID0gbmV3IER5bmFtb0RCQ2xpZW50KHt9KTtcbmNvbnN0IGRvY0NsaWVudCA9IER5bmFtb0RCRG9jdW1lbnRDbGllbnQuZnJvbShkeW5hbW9DbGllbnQpO1xuXG5jb25zdCBUQUJMRV9OQU1FID0gcHJvY2Vzcy5lbnYuRFlOQU1PREJfVEFCTEVfVklERU8hO1xuXG4vLyBDT1JT44OY44OD44OA44O844KS5a6a576pXG5jb25zdCBDT1JTX0hFQURFUlMgPSB7XG4gICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ0NvbnRlbnQtVHlwZSxBdXRob3JpemF0aW9uLFgtQW16LURhdGUsWC1BcGktS2V5LFgtQW16LVNlY3VyaXR5LVRva2VuJyxcbiAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHMnOiAnR0VULFBPU1QsREVMRVRFLE9QVElPTlMnLFxuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctQ3JlZGVudGlhbHMnOiAndHJ1ZSdcbn07XG5cbmludGVyZmFjZSBMaXN0VmlkZW9zUXVlcnlQYXJhbXMge1xuICBsaW1pdD86IHN0cmluZztcbiAgbGFzdEV2YWx1YXRlZEtleT86IHN0cmluZztcbiAgc2VhcmNoPzogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgaGFuZGxlcjogQVBJR2F0ZXdheVByb3h5SGFuZGxlciA9IGFzeW5jIChldmVudCk6IFByb21pc2U8QVBJR2F0ZXdheVByb3h5UmVzdWx0PiA9PiB7XG4gIHRyeSB7XG4gICAgY29uc3QgcXVlcnlQYXJhbXM6IExpc3RWaWRlb3NRdWVyeVBhcmFtcyA9IGV2ZW50LnF1ZXJ5U3RyaW5nUGFyYW1ldGVycyB8fCB7fTtcbiAgICBjb25zdCBsaW1pdCA9IHF1ZXJ5UGFyYW1zLmxpbWl0ID8gcGFyc2VJbnQocXVlcnlQYXJhbXMubGltaXQsIDEwKSA6IDUwO1xuICAgIGNvbnN0IHNlYXJjaCA9IHF1ZXJ5UGFyYW1zLnNlYXJjaDtcbiAgICBcbiAgICBsZXQgbGFzdEV2YWx1YXRlZEtleTtcbiAgICBpZiAocXVlcnlQYXJhbXMubGFzdEV2YWx1YXRlZEtleSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgbGFzdEV2YWx1YXRlZEtleSA9IEpTT04ucGFyc2UoZGVjb2RlVVJJQ29tcG9uZW50KHF1ZXJ5UGFyYW1zLmxhc3RFdmFsdWF0ZWRLZXkpKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiA0MDAsXG4gICAgICAgICAgaGVhZGVyczogQ09SU19IRUFERVJTLFxuICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgICAgZXJyb3I6IHtcbiAgICAgICAgICAgICAgY29kZTogJ0lOVkFMSURfUEFSQU1FVEVSJyxcbiAgICAgICAgICAgICAgbWVzc2FnZTogJ0ludmFsaWQgbGFzdEV2YWx1YXRlZEtleSBmb3JtYXQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KSxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyDplovnmbrnkrDlooPjgafjga/oqo3oqLzjgpLjgrnjgq3jg4Pjg5dcbiAgICBsZXQgY2xhaW1zLCB1c2VyR3JvdXBzOiBzdHJpbmdbXSwgb3JnYW5pemF0aW9uSWQsIHNob3BJZDtcbiAgICBcbiAgICBpZiAocHJvY2Vzcy5lbnYuRU5WSVJPTk1FTlQgPT09ICdkZXYnICYmIGV2ZW50LmhlYWRlcnM/LlsneC1kZXZlbG9wbWVudC1tb2RlJ10gPT09ICd0cnVlJykge1xuICAgICAgY29uc29sZS5sb2coJ0RldmVsb3BtZW50IG1vZGU6IFNraXBwaW5nIGF1dGhlbnRpY2F0aW9uJyk7XG4gICAgICBjbGFpbXMgPSBudWxsO1xuICAgICAgdXNlckdyb3VwcyA9IFsnc3lzdGVtLWFkbWluJ107XG4gICAgICBvcmdhbml6YXRpb25JZCA9IG51bGw7XG4gICAgICBzaG9wSWQgPSBudWxsO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyDjg6bjg7zjgrbjg7zmg4XloLHjgpLlj5blvpfvvIhDb2duaXRv44GL44KJ77yJXG4gICAgICBjbGFpbXMgPSBldmVudC5yZXF1ZXN0Q29udGV4dD8uYXV0aG9yaXplcj8uY2xhaW1zO1xuICAgICAgdXNlckdyb3VwcyA9IGNsYWltcz8uWydjb2duaXRvOmdyb3VwcyddIHx8IFtdO1xuICAgICAgb3JnYW5pemF0aW9uSWQgPSBjbGFpbXM/LlsnY3VzdG9tOm9yZ2FuaXphdGlvbklkJ107XG4gICAgICBzaG9wSWQgPSBjbGFpbXM/LlsnY3VzdG9tOnNob3BJZCddO1xuICAgIH1cblxuICAgIGxldCByZXN1bHQ7XG4gICAgXG4gICAgaWYgKHVzZXJHcm91cHMuaW5jbHVkZXMoJ3N5c3RlbS1hZG1pbicpKSB7XG4gICAgICAvLyBzeXN0ZW0tYWRtaW46IOWFqOWLleeUu+OCkumWsuimp+WPr+iDvVxuICAgICAgY29uc3QgY29tbWFuZCA9IG5ldyBTY2FuQ29tbWFuZCh7XG4gICAgICAgIFRhYmxlTmFtZTogVEFCTEVfTkFNRSxcbiAgICAgICAgTGltaXQ6IGxpbWl0LFxuICAgICAgICBFeGNsdXNpdmVTdGFydEtleTogbGFzdEV2YWx1YXRlZEtleSxcbiAgICAgIH0pO1xuICAgICAgcmVzdWx0ID0gYXdhaXQgZG9jQ2xpZW50LnNlbmQoY29tbWFuZCk7XG4gICAgfSBlbHNlIGlmICh1c2VyR3JvdXBzLmluY2x1ZGVzKCdvcmdhbml6YXRpb24tYWRtaW4nKSAmJiBvcmdhbml6YXRpb25JZCkge1xuICAgICAgLy8gb3JnYW5pemF0aW9uLWFkbWluOiDoh6rliIbjga7ku6PnkIblupfphY3kuIvjga7lhajli5XnlLvjgpLplrLopqflj6/og73vvIjlhajosqnlo7LlupflkKvjgoDvvIlcbiAgICAgIGNvbnN0IGNvbW1hbmQgPSBuZXcgUXVlcnlDb21tYW5kKHtcbiAgICAgICAgVGFibGVOYW1lOiBUQUJMRV9OQU1FLFxuICAgICAgICBJbmRleE5hbWU6ICdvcmdhbml6YXRpb25JZC11cGxvYWREYXRlLWluZGV4JyxcbiAgICAgICAgS2V5Q29uZGl0aW9uRXhwcmVzc2lvbjogJ29yZ2FuaXphdGlvbklkID0gOm9yZ2FuaXphdGlvbklkJyxcbiAgICAgICAgRXhwcmVzc2lvbkF0dHJpYnV0ZVZhbHVlczoge1xuICAgICAgICAgICc6b3JnYW5pemF0aW9uSWQnOiBvcmdhbml6YXRpb25JZCxcbiAgICAgICAgfSxcbiAgICAgICAgTGltaXQ6IGxpbWl0LFxuICAgICAgICBFeGNsdXNpdmVTdGFydEtleTogbGFzdEV2YWx1YXRlZEtleSxcbiAgICAgICAgU2NhbkluZGV4Rm9yd2FyZDogZmFsc2UsIC8vIOaWsOOBl+OBhOmghlxuICAgICAgfSk7XG4gICAgICByZXN1bHQgPSBhd2FpdCBkb2NDbGllbnQuc2VuZChjb21tYW5kKTtcbiAgICB9IGVsc2UgaWYgKHVzZXJHcm91cHMuaW5jbHVkZXMoJ3Nob3AtdXNlcicpICYmIHNob3BJZCkge1xuICAgICAgLy8gc2hvcC11c2VyOiDoh6rliIbjga7osqnlo7Llupfjga7li5XnlLvjga7jgb/plrLopqflj6/og71cbiAgICAgIGNvbnN0IGNvbW1hbmQgPSBuZXcgUXVlcnlDb21tYW5kKHtcbiAgICAgICAgVGFibGVOYW1lOiBUQUJMRV9OQU1FLFxuICAgICAgICBJbmRleE5hbWU6ICdzaG9wSWQtdXBsb2FkRGF0ZS1pbmRleCcsXG4gICAgICAgIEtleUNvbmRpdGlvbkV4cHJlc3Npb246ICdzaG9wSWQgPSA6c2hvcElkJyxcbiAgICAgICAgRXhwcmVzc2lvbkF0dHJpYnV0ZVZhbHVlczoge1xuICAgICAgICAgICc6c2hvcElkJzogc2hvcElkLFxuICAgICAgICB9LFxuICAgICAgICBMaW1pdDogbGltaXQsXG4gICAgICAgIEV4Y2x1c2l2ZVN0YXJ0S2V5OiBsYXN0RXZhbHVhdGVkS2V5LFxuICAgICAgICBTY2FuSW5kZXhGb3J3YXJkOiBmYWxzZSwgLy8g5paw44GX44GE6aCGXG4gICAgICB9KTtcbiAgICAgIHJlc3VsdCA9IGF3YWl0IGRvY0NsaWVudC5zZW5kKGNvbW1hbmQpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzdGF0dXNDb2RlOiA0MDMsXG4gICAgICAgIGhlYWRlcnM6IENPUlNfSEVBREVSUyxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgIGVycm9yOiB7XG4gICAgICAgICAgICBjb2RlOiAnRk9SQklEREVOJyxcbiAgICAgICAgICAgIG1lc3NhZ2U6ICdBY2Nlc3MgZGVuaWVkJyxcbiAgICAgICAgICB9LFxuICAgICAgICB9KSxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgLy8g5qSc57Si44OV44Kj44Or44K/44Oq44Oz44Kw77yI44Kv44Op44Kk44Ki44Oz44OI5YG077yJXG4gICAgbGV0IGl0ZW1zID0gcmVzdWx0Lkl0ZW1zIHx8IFtdO1xuICAgIGlmIChzZWFyY2gpIHtcbiAgICAgIGNvbnN0IHNlYXJjaExvd2VyID0gc2VhcmNoLnRvTG93ZXJDYXNlKCk7XG4gICAgICBpdGVtcyA9IGl0ZW1zLmZpbHRlcigoaXRlbTogYW55KSA9PiBcbiAgICAgICAgaXRlbS50aXRsZT8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hMb3dlcikgfHxcbiAgICAgICAgaXRlbS5kZXNjcmlwdGlvbj8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hMb3dlcikgfHxcbiAgICAgICAgaXRlbS52aWRlb0lkPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaExvd2VyKVxuICAgICAgKTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgaGVhZGVyczogQ09SU19IRUFERVJTLFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgdmlkZW9zOiBpdGVtcyxcbiAgICAgICAgICB0b3RhbENvdW50OiBpdGVtcy5sZW5ndGgsXG4gICAgICAgICAgbGFzdEV2YWx1YXRlZEtleTogcmVzdWx0Lkxhc3RFdmFsdWF0ZWRLZXkgXG4gICAgICAgICAgICA/IGVuY29kZVVSSUNvbXBvbmVudChKU09OLnN0cmluZ2lmeShyZXN1bHQuTGFzdEV2YWx1YXRlZEtleSkpXG4gICAgICAgICAgICA6IG51bGwsXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICB9O1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGxpc3RpbmcgdmlkZW9zOicsIGVycm9yKTtcbiAgICByZXR1cm4ge1xuICAgICAgc3RhdHVzQ29kZTogNTAwLFxuICAgICAgaGVhZGVyczogQ09SU19IRUFERVJTLFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgZXJyb3I6IHtcbiAgICAgICAgICBjb2RlOiAnSU5URVJOQUxfU0VSVkVSX0VSUk9SJyxcbiAgICAgICAgICBtZXNzYWdlOiAnRmFpbGVkIHRvIGxpc3QgdmlkZW9zJyxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgIH07XG4gIH1cbn07XG5cbiJdfQ==