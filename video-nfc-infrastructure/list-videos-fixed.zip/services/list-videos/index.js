"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamoClient = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
const TABLE_NAME = process.env.DYNAMODB_TABLE_VIDEO;
const handler = async (event) => {
    try {
        const queryParams = event.queryStringParameters || {};
        const limit = queryParams.limit ? parseInt(queryParams.limit, 10) : 50;
        const search = queryParams.search;
        let lastEvaluatedKey;
        if (queryParams.lastEvaluatedKey) {
            try {
                lastEvaluatedKey = JSON.parse(decodeURIComponent(queryParams.lastEvaluatedKey));
            }
            catch (e) {
                return {
                    statusCode: 400,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*',
                    },
                    body: JSON.stringify({
                        success: false,
                        error: {
                            code: 'INVALID_PARAMETER',
                            message: 'Invalid lastEvaluatedKey format',
                        },
                    }),
                };
            }
        }
        // ユーザー情報を取得（Cognitoから）
        const claims = event.requestContext?.authorizer?.claims;
        const userGroups = claims?.['cognito:groups'] || [];
        const organizationId = claims?.['custom:organizationId'];
        const shopId = claims?.['custom:shopId'];
        let result;
        if (userGroups.includes('system-admin')) {
            // system-admin: 全動画を閲覧可能
            const command = new lib_dynamodb_1.ScanCommand({
                TableName: TABLE_NAME,
                Limit: limit,
                ExclusiveStartKey: lastEvaluatedKey,
            });
            result = await docClient.send(command);
        }
        else if (userGroups.includes('organization-admin') && organizationId) {
            // organization-admin: 自分の代理店配下の全動画を閲覧可能（全販売店含む）
            const command = new lib_dynamodb_1.QueryCommand({
                TableName: TABLE_NAME,
                IndexName: 'organizationId-uploadDate-index',
                KeyConditionExpression: 'organizationId = :organizationId',
                ExpressionAttributeValues: {
                    ':organizationId': organizationId,
                },
                Limit: limit,
                ExclusiveStartKey: lastEvaluatedKey,
                ScanIndexForward: false, // 新しい順
            });
            result = await docClient.send(command);
        }
        else if (userGroups.includes('shop-user') && shopId) {
            // shop-user: 自分の販売店の動画のみ閲覧可能
            const command = new lib_dynamodb_1.QueryCommand({
                TableName: TABLE_NAME,
                IndexName: 'shopId-uploadDate-index',
                KeyConditionExpression: 'shopId = :shopId',
                ExpressionAttributeValues: {
                    ':shopId': shopId,
                },
                Limit: limit,
                ExclusiveStartKey: lastEvaluatedKey,
                ScanIndexForward: false, // 新しい順
            });
            result = await docClient.send(command);
        }
        else {
            return {
                statusCode: 403,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                },
                body: JSON.stringify({
                    success: false,
                    error: {
                        code: 'FORBIDDEN',
                        message: 'Access denied',
                    },
                }),
            };
        }
        // 検索フィルタリング（クライアント側）
        let items = result.Items || [];
        if (search) {
            const searchLower = search.toLowerCase();
            items = items.filter((item) => item.title?.toLowerCase().includes(searchLower) ||
                item.description?.toLowerCase().includes(searchLower) ||
                item.videoId?.toLowerCase().includes(searchLower));
        }
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify({
                success: true,
                data: {
                    videos: items,
                    totalCount: items.length,
                    lastEvaluatedKey: result.LastEvaluatedKey
                        ? encodeURIComponent(JSON.stringify(result.LastEvaluatedKey))
                        : null,
                },
            }),
        };
    }
    catch (error) {
        console.error('Error listing videos:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify({
                success: false,
                error: {
                    code: 'INTERNAL_SERVER_ERROR',
                    message: 'Failed to list videos',
                },
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSw4REFBMEQ7QUFDMUQsd0RBQTBGO0FBRTFGLE1BQU0sWUFBWSxHQUFHLElBQUksZ0NBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUM1QyxNQUFNLFNBQVMsR0FBRyxxQ0FBc0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7QUFFNUQsTUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBcUIsQ0FBQztBQVE5QyxNQUFNLE9BQU8sR0FBMkIsS0FBSyxFQUFFLEtBQUssRUFBa0MsRUFBRTtJQUM3RixJQUFJLENBQUM7UUFDSCxNQUFNLFdBQVcsR0FBMEIsS0FBSyxDQUFDLHFCQUFxQixJQUFJLEVBQUUsQ0FBQztRQUM3RSxNQUFNLEtBQUssR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQ3ZFLE1BQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUM7UUFFbEMsSUFBSSxnQkFBZ0IsQ0FBQztRQUNyQixJQUFJLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ2pDLElBQUksQ0FBQztnQkFDSCxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7WUFDbEYsQ0FBQztZQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7Z0JBQ1gsT0FBTztvQkFDTCxVQUFVLEVBQUUsR0FBRztvQkFDZixPQUFPLEVBQUU7d0JBQ1AsY0FBYyxFQUFFLGtCQUFrQjt3QkFDbEMsNkJBQTZCLEVBQUUsR0FBRztxQkFDbkM7b0JBQ0QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7d0JBQ25CLE9BQU8sRUFBRSxLQUFLO3dCQUNkLEtBQUssRUFBRTs0QkFDTCxJQUFJLEVBQUUsbUJBQW1COzRCQUN6QixPQUFPLEVBQUUsaUNBQWlDO3lCQUMzQztxQkFDRixDQUFDO2lCQUNILENBQUM7WUFDSixDQUFDO1FBQ0gsQ0FBQztRQUVELHVCQUF1QjtRQUN2QixNQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsY0FBYyxFQUFFLFVBQVUsRUFBRSxNQUFNLENBQUM7UUFDeEQsTUFBTSxVQUFVLEdBQWEsTUFBTSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDOUQsTUFBTSxjQUFjLEdBQUcsTUFBTSxFQUFFLENBQUMsdUJBQXVCLENBQUMsQ0FBQztRQUN6RCxNQUFNLE1BQU0sR0FBRyxNQUFNLEVBQUUsQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUV6QyxJQUFJLE1BQU0sQ0FBQztRQUVYLElBQUksVUFBVSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDO1lBQ3hDLHlCQUF5QjtZQUN6QixNQUFNLE9BQU8sR0FBRyxJQUFJLDBCQUFXLENBQUM7Z0JBQzlCLFNBQVMsRUFBRSxVQUFVO2dCQUNyQixLQUFLLEVBQUUsS0FBSztnQkFDWixpQkFBaUIsRUFBRSxnQkFBZ0I7YUFDcEMsQ0FBQyxDQUFDO1lBQ0gsTUFBTSxHQUFHLE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN6QyxDQUFDO2FBQU0sSUFBSSxVQUFVLENBQUMsUUFBUSxDQUFDLG9CQUFvQixDQUFDLElBQUksY0FBYyxFQUFFLENBQUM7WUFDdkUsZ0RBQWdEO1lBQ2hELE1BQU0sT0FBTyxHQUFHLElBQUksMkJBQVksQ0FBQztnQkFDL0IsU0FBUyxFQUFFLFVBQVU7Z0JBQ3JCLFNBQVMsRUFBRSxpQ0FBaUM7Z0JBQzVDLHNCQUFzQixFQUFFLGtDQUFrQztnQkFDMUQseUJBQXlCLEVBQUU7b0JBQ3pCLGlCQUFpQixFQUFFLGNBQWM7aUJBQ2xDO2dCQUNELEtBQUssRUFBRSxLQUFLO2dCQUNaLGlCQUFpQixFQUFFLGdCQUFnQjtnQkFDbkMsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLE9BQU87YUFDakMsQ0FBQyxDQUFDO1lBQ0gsTUFBTSxHQUFHLE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN6QyxDQUFDO2FBQU0sSUFBSSxVQUFVLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLE1BQU0sRUFBRSxDQUFDO1lBQ3RELDZCQUE2QjtZQUM3QixNQUFNLE9BQU8sR0FBRyxJQUFJLDJCQUFZLENBQUM7Z0JBQy9CLFNBQVMsRUFBRSxVQUFVO2dCQUNyQixTQUFTLEVBQUUseUJBQXlCO2dCQUNwQyxzQkFBc0IsRUFBRSxrQkFBa0I7Z0JBQzFDLHlCQUF5QixFQUFFO29CQUN6QixTQUFTLEVBQUUsTUFBTTtpQkFDbEI7Z0JBQ0QsS0FBSyxFQUFFLEtBQUs7Z0JBQ1osaUJBQWlCLEVBQUUsZ0JBQWdCO2dCQUNuQyxnQkFBZ0IsRUFBRSxLQUFLLEVBQUUsT0FBTzthQUNqQyxDQUFDLENBQUM7WUFDSCxNQUFNLEdBQUcsTUFBTSxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3pDLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTztnQkFDTCxVQUFVLEVBQUUsR0FBRztnQkFDZixPQUFPLEVBQUU7b0JBQ1AsY0FBYyxFQUFFLGtCQUFrQjtvQkFDbEMsNkJBQTZCLEVBQUUsR0FBRztpQkFDbkM7Z0JBQ0QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7b0JBQ25CLE9BQU8sRUFBRSxLQUFLO29CQUNkLEtBQUssRUFBRTt3QkFDTCxJQUFJLEVBQUUsV0FBVzt3QkFDakIsT0FBTyxFQUFFLGVBQWU7cUJBQ3pCO2lCQUNGLENBQUM7YUFDSCxDQUFDO1FBQ0osQ0FBQztRQUVELHFCQUFxQjtRQUNyQixJQUFJLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQztRQUMvQixJQUFJLE1BQU0sRUFBRSxDQUFDO1lBQ1gsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3pDLEtBQUssR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBUyxFQUFFLEVBQUUsQ0FDakMsSUFBSSxDQUFDLEtBQUssRUFBRSxXQUFXLEVBQUUsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDO2dCQUMvQyxJQUFJLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUM7Z0JBQ3JELElBQUksQ0FBQyxPQUFPLEVBQUUsV0FBVyxFQUFFLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUNsRCxDQUFDO1FBQ0osQ0FBQztRQUVELE9BQU87WUFDTCxVQUFVLEVBQUUsR0FBRztZQUNmLE9BQU8sRUFBRTtnQkFDUCxjQUFjLEVBQUUsa0JBQWtCO2dCQUNsQyw2QkFBNkIsRUFBRSxHQUFHO2FBQ25DO1lBQ0QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ25CLE9BQU8sRUFBRSxJQUFJO2dCQUNiLElBQUksRUFBRTtvQkFDSixNQUFNLEVBQUUsS0FBSztvQkFDYixVQUFVLEVBQUUsS0FBSyxDQUFDLE1BQU07b0JBQ3hCLGdCQUFnQixFQUFFLE1BQU0sQ0FBQyxnQkFBZ0I7d0JBQ3ZDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO3dCQUM3RCxDQUFDLENBQUMsSUFBSTtpQkFDVDthQUNGLENBQUM7U0FDSCxDQUFDO0lBQ0osQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzlDLE9BQU87WUFDTCxVQUFVLEVBQUUsR0FBRztZQUNmLE9BQU8sRUFBRTtnQkFDUCxjQUFjLEVBQUUsa0JBQWtCO2dCQUNsQyw2QkFBNkIsRUFBRSxHQUFHO2FBQ25DO1lBQ0QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ25CLE9BQU8sRUFBRSxLQUFLO2dCQUNkLEtBQUssRUFBRTtvQkFDTCxJQUFJLEVBQUUsdUJBQXVCO29CQUM3QixPQUFPLEVBQUUsdUJBQXVCO2lCQUNqQzthQUNGLENBQUM7U0FDSCxDQUFDO0lBQ0osQ0FBQztBQUNILENBQUMsQ0FBQztBQXRJVyxRQUFBLE9BQU8sV0FzSWxCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQVBJR2F0ZXdheVByb3h5SGFuZGxlciwgQVBJR2F0ZXdheVByb3h5UmVzdWx0IH0gZnJvbSAnYXdzLWxhbWJkYSc7XG5pbXBvcnQgeyBEeW5hbW9EQkNsaWVudCB9IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC1keW5hbW9kYic7XG5pbXBvcnQgeyBEeW5hbW9EQkRvY3VtZW50Q2xpZW50LCBRdWVyeUNvbW1hbmQsIFNjYW5Db21tYW5kIH0gZnJvbSAnQGF3cy1zZGsvbGliLWR5bmFtb2RiJztcblxuY29uc3QgZHluYW1vQ2xpZW50ID0gbmV3IER5bmFtb0RCQ2xpZW50KHt9KTtcbmNvbnN0IGRvY0NsaWVudCA9IER5bmFtb0RCRG9jdW1lbnRDbGllbnQuZnJvbShkeW5hbW9DbGllbnQpO1xuXG5jb25zdCBUQUJMRV9OQU1FID0gcHJvY2Vzcy5lbnYuRFlOQU1PREJfVEFCTEVfVklERU8hO1xuXG5pbnRlcmZhY2UgTGlzdFZpZGVvc1F1ZXJ5UGFyYW1zIHtcbiAgbGltaXQ/OiBzdHJpbmc7XG4gIGxhc3RFdmFsdWF0ZWRLZXk/OiBzdHJpbmc7XG4gIHNlYXJjaD86IHN0cmluZztcbn1cblxuZXhwb3J0IGNvbnN0IGhhbmRsZXI6IEFQSUdhdGV3YXlQcm94eUhhbmRsZXIgPSBhc3luYyAoZXZlbnQpOiBQcm9taXNlPEFQSUdhdGV3YXlQcm94eVJlc3VsdD4gPT4ge1xuICB0cnkge1xuICAgIGNvbnN0IHF1ZXJ5UGFyYW1zOiBMaXN0VmlkZW9zUXVlcnlQYXJhbXMgPSBldmVudC5xdWVyeVN0cmluZ1BhcmFtZXRlcnMgfHwge307XG4gICAgY29uc3QgbGltaXQgPSBxdWVyeVBhcmFtcy5saW1pdCA/IHBhcnNlSW50KHF1ZXJ5UGFyYW1zLmxpbWl0LCAxMCkgOiA1MDtcbiAgICBjb25zdCBzZWFyY2ggPSBxdWVyeVBhcmFtcy5zZWFyY2g7XG4gICAgXG4gICAgbGV0IGxhc3RFdmFsdWF0ZWRLZXk7XG4gICAgaWYgKHF1ZXJ5UGFyYW1zLmxhc3RFdmFsdWF0ZWRLZXkpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGxhc3RFdmFsdWF0ZWRLZXkgPSBKU09OLnBhcnNlKGRlY29kZVVSSUNvbXBvbmVudChxdWVyeVBhcmFtcy5sYXN0RXZhbHVhdGVkS2V5KSk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgICAgICBlcnJvcjoge1xuICAgICAgICAgICAgICBjb2RlOiAnSU5WQUxJRF9QQVJBTUVURVInLFxuICAgICAgICAgICAgICBtZXNzYWdlOiAnSW52YWxpZCBsYXN0RXZhbHVhdGVkS2V5IGZvcm1hdCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pLFxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIOODpuODvOOCtuODvOaDheWgseOCkuWPluW+l++8iENvZ25pdG/jgYvjgonvvIlcbiAgICBjb25zdCBjbGFpbXMgPSBldmVudC5yZXF1ZXN0Q29udGV4dD8uYXV0aG9yaXplcj8uY2xhaW1zO1xuICAgIGNvbnN0IHVzZXJHcm91cHM6IHN0cmluZ1tdID0gY2xhaW1zPy5bJ2NvZ25pdG86Z3JvdXBzJ10gfHwgW107XG4gICAgY29uc3Qgb3JnYW5pemF0aW9uSWQgPSBjbGFpbXM/LlsnY3VzdG9tOm9yZ2FuaXphdGlvbklkJ107XG4gICAgY29uc3Qgc2hvcElkID0gY2xhaW1zPy5bJ2N1c3RvbTpzaG9wSWQnXTtcblxuICAgIGxldCByZXN1bHQ7XG4gICAgXG4gICAgaWYgKHVzZXJHcm91cHMuaW5jbHVkZXMoJ3N5c3RlbS1hZG1pbicpKSB7XG4gICAgICAvLyBzeXN0ZW0tYWRtaW46IOWFqOWLleeUu+OCkumWsuimp+WPr+iDvVxuICAgICAgY29uc3QgY29tbWFuZCA9IG5ldyBTY2FuQ29tbWFuZCh7XG4gICAgICAgIFRhYmxlTmFtZTogVEFCTEVfTkFNRSxcbiAgICAgICAgTGltaXQ6IGxpbWl0LFxuICAgICAgICBFeGNsdXNpdmVTdGFydEtleTogbGFzdEV2YWx1YXRlZEtleSxcbiAgICAgIH0pO1xuICAgICAgcmVzdWx0ID0gYXdhaXQgZG9jQ2xpZW50LnNlbmQoY29tbWFuZCk7XG4gICAgfSBlbHNlIGlmICh1c2VyR3JvdXBzLmluY2x1ZGVzKCdvcmdhbml6YXRpb24tYWRtaW4nKSAmJiBvcmdhbml6YXRpb25JZCkge1xuICAgICAgLy8gb3JnYW5pemF0aW9uLWFkbWluOiDoh6rliIbjga7ku6PnkIblupfphY3kuIvjga7lhajli5XnlLvjgpLplrLopqflj6/og73vvIjlhajosqnlo7LlupflkKvjgoDvvIlcbiAgICAgIGNvbnN0IGNvbW1hbmQgPSBuZXcgUXVlcnlDb21tYW5kKHtcbiAgICAgICAgVGFibGVOYW1lOiBUQUJMRV9OQU1FLFxuICAgICAgICBJbmRleE5hbWU6ICdvcmdhbml6YXRpb25JZC11cGxvYWREYXRlLWluZGV4JyxcbiAgICAgICAgS2V5Q29uZGl0aW9uRXhwcmVzc2lvbjogJ29yZ2FuaXphdGlvbklkID0gOm9yZ2FuaXphdGlvbklkJyxcbiAgICAgICAgRXhwcmVzc2lvbkF0dHJpYnV0ZVZhbHVlczoge1xuICAgICAgICAgICc6b3JnYW5pemF0aW9uSWQnOiBvcmdhbml6YXRpb25JZCxcbiAgICAgICAgfSxcbiAgICAgICAgTGltaXQ6IGxpbWl0LFxuICAgICAgICBFeGNsdXNpdmVTdGFydEtleTogbGFzdEV2YWx1YXRlZEtleSxcbiAgICAgICAgU2NhbkluZGV4Rm9yd2FyZDogZmFsc2UsIC8vIOaWsOOBl+OBhOmghlxuICAgICAgfSk7XG4gICAgICByZXN1bHQgPSBhd2FpdCBkb2NDbGllbnQuc2VuZChjb21tYW5kKTtcbiAgICB9IGVsc2UgaWYgKHVzZXJHcm91cHMuaW5jbHVkZXMoJ3Nob3AtdXNlcicpICYmIHNob3BJZCkge1xuICAgICAgLy8gc2hvcC11c2VyOiDoh6rliIbjga7osqnlo7Llupfjga7li5XnlLvjga7jgb/plrLopqflj6/og71cbiAgICAgIGNvbnN0IGNvbW1hbmQgPSBuZXcgUXVlcnlDb21tYW5kKHtcbiAgICAgICAgVGFibGVOYW1lOiBUQUJMRV9OQU1FLFxuICAgICAgICBJbmRleE5hbWU6ICdzaG9wSWQtdXBsb2FkRGF0ZS1pbmRleCcsXG4gICAgICAgIEtleUNvbmRpdGlvbkV4cHJlc3Npb246ICdzaG9wSWQgPSA6c2hvcElkJyxcbiAgICAgICAgRXhwcmVzc2lvbkF0dHJpYnV0ZVZhbHVlczoge1xuICAgICAgICAgICc6c2hvcElkJzogc2hvcElkLFxuICAgICAgICB9LFxuICAgICAgICBMaW1pdDogbGltaXQsXG4gICAgICAgIEV4Y2x1c2l2ZVN0YXJ0S2V5OiBsYXN0RXZhbHVhdGVkS2V5LFxuICAgICAgICBTY2FuSW5kZXhGb3J3YXJkOiBmYWxzZSwgLy8g5paw44GX44GE6aCGXG4gICAgICB9KTtcbiAgICAgIHJlc3VsdCA9IGF3YWl0IGRvY0NsaWVudC5zZW5kKGNvbW1hbmQpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzdGF0dXNDb2RlOiA0MDMsXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICBlcnJvcjoge1xuICAgICAgICAgICAgY29kZTogJ0ZPUkJJRERFTicsXG4gICAgICAgICAgICBtZXNzYWdlOiAnQWNjZXNzIGRlbmllZCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSksXG4gICAgICB9O1xuICAgIH1cblxuICAgIC8vIOaknOe0ouODleOCo+ODq+OCv+ODquODs+OCsO+8iOOCr+ODqeOCpOOCouODs+ODiOWBtO+8iVxuICAgIGxldCBpdGVtcyA9IHJlc3VsdC5JdGVtcyB8fCBbXTtcbiAgICBpZiAoc2VhcmNoKSB7XG4gICAgICBjb25zdCBzZWFyY2hMb3dlciA9IHNlYXJjaC50b0xvd2VyQ2FzZSgpO1xuICAgICAgaXRlbXMgPSBpdGVtcy5maWx0ZXIoKGl0ZW06IGFueSkgPT4gXG4gICAgICAgIGl0ZW0udGl0bGU/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoTG93ZXIpIHx8XG4gICAgICAgIGl0ZW0uZGVzY3JpcHRpb24/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoTG93ZXIpIHx8XG4gICAgICAgIGl0ZW0udmlkZW9JZD8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hMb3dlcilcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgIGRhdGE6IHtcbiAgICAgICAgICB2aWRlb3M6IGl0ZW1zLFxuICAgICAgICAgIHRvdGFsQ291bnQ6IGl0ZW1zLmxlbmd0aCxcbiAgICAgICAgICBsYXN0RXZhbHVhdGVkS2V5OiByZXN1bHQuTGFzdEV2YWx1YXRlZEtleSBcbiAgICAgICAgICAgID8gZW5jb2RlVVJJQ29tcG9uZW50KEpTT04uc3RyaW5naWZ5KHJlc3VsdC5MYXN0RXZhbHVhdGVkS2V5KSlcbiAgICAgICAgICAgIDogbnVsbCxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgIH07XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgbGlzdGluZyB2aWRlb3M6JywgZXJyb3IpO1xuICAgIHJldHVybiB7XG4gICAgICBzdGF0dXNDb2RlOiA1MDAsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgZXJyb3I6IHtcbiAgICAgICAgICBjb2RlOiAnSU5URVJOQUxfU0VSVkVSX0VSUk9SJyxcbiAgICAgICAgICBtZXNzYWdlOiAnRmFpbGVkIHRvIGxpc3QgdmlkZW9zJyxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgIH07XG4gIH1cbn07XG5cbiJdfQ==