"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
var client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
var lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
var client_s3_1 = require("@aws-sdk/client-s3");
var dynamoClient = new client_dynamodb_1.DynamoDBClient({});
var docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
var s3Client = new client_s3_1.S3Client({});
var TABLE_NAME = process.env.DYNAMODB_TABLE_VIDEO;
var S3_BUCKET_NAME = process.env.S3_BUCKET_NAME;
var ASSETS_BUCKET_NAME = process.env.ASSETS_BUCKET_NAME;
var handler = function (event) { return __awaiter(void 0, void 0, void 0, function () {
    var videoId, getCommand, result, claims, userGroups, userId, userEmail, sourceIp, userOrganizationId, userShopId, videoOrganizationId, videoShopId, uploadedAt, uploadTime, currentTime, sixHoursInMs, timeSinceUpload, s3DeleteResult, deleteVideoCommand, deleteThumbnailCommand, s3Error_1, deleteCommand, error_1;
    var _a, _b, _c, _d, _e, _f, _g;
    return __generator(this, function (_h) {
        switch (_h.label) {
            case 0:
                _h.trys.push([0, 10, , 11]);
                videoId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.videoId;
                if (!videoId) {
                    return [2 /*return*/, {
                            statusCode: 400,
                            headers: {
                                'Content-Type': 'application/json',
                                'Access-Control-Allow-Origin': '*',
                            },
                            body: JSON.stringify({
                                success: false,
                                error: {
                                    code: 'INVALID_PARAMETER',
                                    message: 'videoId is required',
                                },
                            }),
                        }];
                }
                getCommand = new lib_dynamodb_1.GetCommand({
                    TableName: TABLE_NAME,
                    Key: { videoId: videoId },
                });
                return [4 /*yield*/, docClient.send(getCommand)];
            case 1:
                result = _h.sent();
                if (!result.Item) {
                    return [2 /*return*/, {
                            statusCode: 404,
                            headers: {
                                'Content-Type': 'application/json',
                                'Access-Control-Allow-Origin': '*',
                            },
                            body: JSON.stringify({
                                success: false,
                                error: {
                                    code: 'NOT_FOUND',
                                    message: 'Video not found',
                                },
                            }),
                        }];
                }
                claims = ((_c = (_b = event.requestContext) === null || _b === void 0 ? void 0 : _b.authorizer) === null || _c === void 0 ? void 0 : _c.claims) || {};
                userGroups = (claims === null || claims === void 0 ? void 0 : claims['cognito:groups']) || [];
                userId = (claims === null || claims === void 0 ? void 0 : claims.sub) || 'unknown';
                userEmail = (claims === null || claims === void 0 ? void 0 : claims.email) || 'unknown';
                sourceIp = ((_e = (_d = event.requestContext) === null || _d === void 0 ? void 0 : _d.identity) === null || _e === void 0 ? void 0 : _e.sourceIp) || (((_f = event.headers) === null || _f === void 0 ? void 0 : _f['x-forwarded-for']) || '').split(',')[0] || 'unknown';
                if (!userGroups.includes('shop-user')) {
                    // 監査ログ（権限不足）
                    console.warn(JSON.stringify({
                        level: 'WARN',
                        action: 'DELETE_VIDEO',
                        outcome: 'FORBIDDEN',
                        reason: 'Only shop users can delete videos',
                        videoId: videoId,
                        requestId: event.requestContext.requestId,
                        user: { userId: userId, userEmail: userEmail, userGroups: userGroups },
                        sourceIp: sourceIp,
                        timestamp: new Date().toISOString(),
                    }));
                    return [2 /*return*/, {
                            statusCode: 403,
                            headers: {
                                'Content-Type': 'application/json',
                                'Access-Control-Allow-Origin': '*',
                            },
                            body: JSON.stringify({
                                success: false,
                                error: {
                                    code: 'FORBIDDEN',
                                    message: 'Only shop users can delete videos',
                                },
                            }),
                        }];
                }
                userOrganizationId = claims === null || claims === void 0 ? void 0 : claims['custom:organizationId'];
                userShopId = claims === null || claims === void 0 ? void 0 : claims['custom:shopId'];
                videoOrganizationId = result.Item.organizationId;
                videoShopId = result.Item.shopId;
                if (videoShopId && videoShopId !== userShopId) {
                    console.warn(JSON.stringify({
                        level: 'WARN',
                        action: 'DELETE_VIDEO',
                        outcome: 'FORBIDDEN',
                        reason: 'Cannot delete video from different shop',
                        videoId: videoId,
                        requestId: event.requestContext.requestId,
                        user: { userId: userId, userEmail: userEmail, userOrganizationId: userOrganizationId, userShopId: userShopId },
                        video: { videoOrganizationId: videoOrganizationId, videoShopId: videoShopId },
                        sourceIp: sourceIp,
                        timestamp: new Date().toISOString(),
                    }));
                    return [2 /*return*/, {
                            statusCode: 403,
                            headers: {
                                'Content-Type': 'application/json',
                                'Access-Control-Allow-Origin': '*',
                            },
                            body: JSON.stringify({
                                success: false,
                                error: {
                                    code: 'FORBIDDEN',
                                    message: 'You can only delete videos from your own shop',
                                },
                            }),
                        }];
                }
                uploadedAt = result.Item.createdAt;
                if (uploadedAt) {
                    uploadTime = new Date(uploadedAt).getTime();
                    currentTime = Date.now();
                    sixHoursInMs = 6 * 60 * 60 * 1000;
                    timeSinceUpload = currentTime - uploadTime;
                    if (timeSinceUpload > sixHoursInMs) {
                        console.warn(JSON.stringify({
                            level: 'WARN',
                            action: 'DELETE_VIDEO',
                            outcome: 'FORBIDDEN',
                            reason: 'Cannot delete video after 6 hours grace period',
                            videoId: videoId,
                            requestId: event.requestContext.requestId,
                            user: { userId: userId, userEmail: userEmail, userShopId: userShopId },
                            uploadedAt: uploadedAt,
                            timeSinceUploadHours: (timeSinceUpload / (60 * 60 * 1000)).toFixed(2),
                            sourceIp: sourceIp,
                            timestamp: new Date().toISOString(),
                        }));
                        return [2 /*return*/, {
                                statusCode: 403,
                                headers: {
                                    'Content-Type': 'application/json',
                                    'Access-Control-Allow-Origin': '*',
                                },
                                body: JSON.stringify({
                                    success: false,
                                    error: {
                                        code: 'GRACE_PERIOD_EXPIRED',
                                        message: 'Videos can only be deleted within 6 hours of upload',
                                        details: {
                                            uploadedAt: uploadedAt,
                                            timeSinceUploadHours: (timeSinceUpload / (60 * 60 * 1000)).toFixed(2),
                                        },
                                    },
                                }),
                            }];
                    }
                }
                s3DeleteResult = {};
                _h.label = 2;
            case 2:
                _h.trys.push([2, 7, , 8]);
                if (!result.Item.s3Key) return [3 /*break*/, 4];
                deleteVideoCommand = new client_s3_1.DeleteObjectCommand({
                    Bucket: S3_BUCKET_NAME,
                    Key: result.Item.s3Key,
                });
                return [4 /*yield*/, s3Client.send(deleteVideoCommand)];
            case 3:
                _h.sent();
                s3DeleteResult.video = true;
                _h.label = 4;
            case 4:
                if (!result.Item.thumbnailS3Key) return [3 /*break*/, 6];
                deleteThumbnailCommand = new client_s3_1.DeleteObjectCommand({
                    Bucket: ASSETS_BUCKET_NAME,
                    Key: result.Item.thumbnailS3Key,
                });
                return [4 /*yield*/, s3Client.send(deleteThumbnailCommand)];
            case 5:
                _h.sent();
                s3DeleteResult.thumbnail = true;
                _h.label = 6;
            case 6: return [3 /*break*/, 8];
            case 7:
                s3Error_1 = _h.sent();
                console.error(JSON.stringify({
                    level: 'ERROR',
                    action: 'DELETE_VIDEO_S3',
                    outcome: 'ERROR',
                    videoId: videoId,
                    requestId: event.requestContext.requestId,
                    user: { userId: userId, userEmail: userEmail },
                    sourceIp: sourceIp,
                    error: (s3Error_1 === null || s3Error_1 === void 0 ? void 0 : s3Error_1.message) || 'Unknown S3 error',
                    timestamp: new Date().toISOString(),
                }));
                return [3 /*break*/, 8];
            case 8:
                deleteCommand = new lib_dynamodb_1.DeleteCommand({
                    TableName: TABLE_NAME,
                    Key: { videoId: videoId },
                });
                return [4 /*yield*/, docClient.send(deleteCommand)];
            case 9:
                _h.sent();
                // 監査ログ（成功）
                console.log(JSON.stringify({
                    level: 'INFO',
                    action: 'DELETE_VIDEO',
                    outcome: 'SUCCESS',
                    videoId: videoId,
                    s3DeleteResult: s3DeleteResult,
                    requestId: event.requestContext.requestId,
                    user: { userId: userId, userEmail: userEmail, userGroups: userGroups },
                    sourceIp: sourceIp,
                    timestamp: new Date().toISOString(),
                }));
                return [2 /*return*/, {
                        statusCode: 200,
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*',
                        },
                        body: JSON.stringify({
                            success: true,
                            data: {
                                message: 'Video deleted successfully',
                                videoId: videoId,
                            },
                        }),
                    }];
            case 10:
                error_1 = _h.sent();
                console.error(JSON.stringify({
                    level: 'ERROR',
                    action: 'DELETE_VIDEO',
                    outcome: 'ERROR',
                    requestId: (_g = event.requestContext) === null || _g === void 0 ? void 0 : _g.requestId,
                    error: (error_1 === null || error_1 === void 0 ? void 0 : error_1.message) || 'Unknown error',
                    timestamp: new Date().toISOString(),
                }));
                return [2 /*return*/, {
                        statusCode: 500,
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*',
                        },
                        body: JSON.stringify({
                            success: false,
                            error: {
                                code: 'INTERNAL_SERVER_ERROR',
                                message: 'Failed to delete video',
                            },
                        }),
                    }];
            case 11: return [2 /*return*/];
        }
    });
}); };
exports.handler = handler;
